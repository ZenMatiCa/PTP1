require "./Rechteck"
require "./Dreieck"
class Haus

  #TODO
 def initialize(dach_farbe)

   @ABSTAND = 100
   @fassade = Rechteck.new(100+@ABSTAND, 100+@ABSTAND, 90, "orange", false)
   @tuer = Rechteck.new(116, 90, 10, 80, "orange", false)
   @fenster = Kreis.new(116, 90, 10, "orange", false)
   @dach = Dreieck.new(116, 90, 10, 80, "orange", false)


 end

  # TODO
 def sichtbar_machen()
   @fassade.sichtbar_machen()
   @tuer.sichtbar_machen()
   @fenster.sichtbar_machen()
   @dach..sichtbar_machen()
 end

  # TODO
 def tages_ansicht()
 end

  # TODO
 def nacht_ansicht()
 end

  # TODO
 def position()
 end

  # TODO Lösen Sie diese Methode durch geeigneten Aufruf der Methode bewegen der Klasse Haus
 def auf_position_setzen(x,y)
 end

  # TODO
 def bewegen(delta_x,delta_y,wdh,wdh_nach,starten_nach)
 end
end