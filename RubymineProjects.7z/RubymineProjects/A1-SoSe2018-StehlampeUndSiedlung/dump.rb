class Dump

  def bewegen(delta_x,delta_y,wdh,wdh_nach,starten_nach)

  end

