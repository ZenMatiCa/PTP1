require "./Haus"
class Siedlung

  # TODO
  #def initialize()
  #end

  # TODO
  #def sichtbar_machen()
  #end
end